function [vect ld] = putereinversa ( A, h )
  
  y = [ 1 1 1 ];
  max = 96;
  for i = 1 : 3
    d(i) = A(i, i) - h;
    endfor
  for i = 1 : 2
    s(i) = A(i, i + 1);
    endfor
  
  for k = 1 : max
    z = Thomas(s, d, y);
    y = z * (1 / norm(z));
    ld(k) = y * A * y';
    h = ld(k);
    endfor
  vect = y;
  
  endfunction