function x = Thomas ( a, b, d )
  
  n = length(b);
  
  a0(1) = a(1) / b(1);
  
  for i = 2 : n - 1
    a0(i) = a(i) / (b(i) - a0(i - 1) * a(i - 1));
    endfor
  
  d0(1) = d(1) / b(1);
  
  for i = 2 : n
    d0(i) = (d(i) - d0(i - 1) * a(i - 1)) / (b(i) - a0(i - 1) * a(i - 1));
    endfor
  
  x(n) = d0(n);
  
  for i = n - 1 : -1 : 1
    x(i) = d0(i) - a0(i) * x(i + 1);
    endfor
  
  endfunction