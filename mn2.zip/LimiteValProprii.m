function [limita_inf, limita_sup] = LimiteValProprii(d, s) %Se aplica, dupa teorema lui Gershgorin, algoritmul pentru incadrarea tuturor valorilor proprii ale matricei intre doua limite.
  
  dimensMatr = length(d); %se retine dimensiunea matricei in variabile dimensMatr
  
  %in vectorul cu minime, pentru obtinerea fiecarui element se scad modulele celorlalte elemente din elementul de pe diagonala principala de pe linia respectiva. La adunare, nu se scad, ci se aduna modulele elementelor de pe linia respectiva, in afara de cel de pe coloana principala, la elementul de pe coloana principala.
  %deoarece pe prima si pe ultima linie din matrice mai e doar un element nenul in afara de diagonala principala, se iau in considerare mai intai aceste cazuri particulare.
  minimum(1) = d(1) - abs(s(1));
  minimum(dimensMatr) = d(dimensMatr) - abs(s(dimensMatr - 1));
  maximum(1) = d(1) + abs(s(1));
  maximum(dimensMatr) = d(dimensMatr) + abs(s(dimensMatr - 1));
  
  %Acelasi algoritm se urmareste si pentru iteratiile de la 2 la dimensMatr
  for i = 2 : dimensMatr - 1
    minimum(i) = d(i) - abs(s(i - 1)) - abs(s(i));
    maximum(i) = d(i) + abs(s(i - 1)) + abs(s(i));
    endfor
  
  %se initializeaza limitele, pentru a se putea compara cu valorile celelalte din vectorii minimum, respectiv maximum
  limita_inf = minimum(1);
  limita_sup = maximum(1);
  
  %se aleg minimele, respectiv maximele din vectorii 'minimum', respectiv 'maximum', si se apoi ele se atribuie limitelor inferioare, respectiv superioare, pe care le aveam de aflat (limita_inf, respectiv limita_sup)
  for i = 1 : dimensMatr
    if limita_inf > minimum(i)
      limita_inf = minimum(i);
      endif
    if limita_sup < maximum(i)
      limita_sup = maximum(i);
      endif
    endfor
  
  endfunction