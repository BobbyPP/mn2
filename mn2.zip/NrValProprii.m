function numvp = NrValProprii(d, s, val_lambda)
  
  numvp = 0; %initializarea numarului de valori proprii cu 0
  P = ValoriPolinoame(d, s, val_lambda); %generarea sirului de polinoame, calculate in punctul val_lambda
  lenP = length(P);
  
  for i = 1 : lenP - 1
    if sign(P(i) * P(i + 1)) < 0 || sign(P(i)) == 0 %conditia pentru schimbarea de semn, incluzand cazul in care daca P(i) este 0, acesta se considera de semn opus valorii polinomului precedent.
      numvp = numvp + 1; %calcularea efectiva a numarului de valori proprii ale matricei, mai mici decat val_lambda dat.
      endif
    endfor
  
  endfunction