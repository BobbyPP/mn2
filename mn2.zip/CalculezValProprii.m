function vp = CalculezValProprii(d, s, m, tol)
  
  %Se ajusteaza valoarea lui m, daca input-ul este prea mare sau prea mic.
  if m > length(d)
    m = length(d);
    endif
  
  if m < 1
    m = 1;
    endif
  
  %Se initializeaza sirul ce delimiteaza in intervale valorile proprii ale matricei.
  r = IntervaleValProprii(d, s, m);
  
  n = length(d); %In n se retine ordinul matricei.
  
  %Algoritmul calculat consta mai intai in calcularea coeficientilor polinomului caracteristic.
  %Pentru usurinta calcularii acestor coeficienti, se utilizeaza matricea P.
  %Pe fiecare linie i a matricei P, se pun coeficientii polinomului P(i) din sirul recurent de polinoame. Ce ramane necompletat, ramane egal cu 0. Nu consideram sirul de polinoame de la 0 la n, ci de la 1 la n + 1.
  P = zeros(n + 1);
  P(1, 1) = 1;
  P(2, 1) = -1;
  P(2, 2) = d(1);
  
  %S-au completat primele doua linii ale matricei P. Se completeaza restul, folosind relatia de recurenta a sirului de polinoame.
  for i = 2 : n
    for j = 1 : i - 1
      ps(j) = P(i - 1, j);
      endfor
    for j = 1 : i
      pd(j) = P(i, j);
      endfor
    dp = [-1 d(i)];
    dP = multiplpol(dp, pd); %Functia multiplpol realizeaza inmultirea dintre doua polinoame, returnand coeficientii polinomului rezultat.
    for j = 1 : 2
      P(i + 1, j) = dP(j);
      endfor
    for j = 3 : i + 1
      P(i + 1, j) = dP(j) - ps(j - 2) * s(i - 1) * s(i - 1);
      endfor
    endfor
  
  for i = 1 : n + 1
    polinomCaracteristic(i) = P(n + 1, i); %Polinomul caracteristic isi are in mod evident coeficientii pe ultima linie a matricei.
    endfor
  
  for i = 1 : m
    vp(i) = bisectie(polinomCaracteristic, r(i), r(i + 1), tol); %Se realizeaza metoda bisectiei pe fiecare dintre intervalele [r(i) r(i + 1)], pentru aflarea unicei solutii ale polinomului caracteristic din intervalul respectiv (care este exact o valoarea proprie in interiorul acelui interval).
    endfor
  
  endfunction