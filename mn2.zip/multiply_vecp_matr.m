function vecp_mult_A = multiply_vecp_matr (d, s, vecp)
  
  len_d = length(d);
  
  vecp_mult_A(1) = vecp(1) * d(1) + vecp(2) * s(1);
  for i = 2 : len_d - 1
    vecp_mult_A(i) = vecp(i - 1) * s(i - 1) + vecp(i) * d(i) + vecp(i + 1) * s(i);
    endfor
  vecp_mult_A(len_d) = vecp(len_d - 1) * s(len_d - 1) + vecp(len_d) * d(len_d);
  
  endfunction