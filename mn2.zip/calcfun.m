function [val] = calcfun (f, x)
  
  lengt = length(f);
  val = 0;
  for i = 1 : lengt
    val = val + f(lengt - i + 1) * x^(i-1);
    endfor
  
  endfunction