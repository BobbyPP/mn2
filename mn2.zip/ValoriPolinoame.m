function P = ValoriPolinoame(d, s, val_lambda)
  
  P(1) = 1;
  P(2) = d(1) - val_lambda; %primele doua valori ale sirului P(k), calculate in punctul val_lambda, 1 <= k <= n
  
  n = length(d);
  for i = 2 : n
    P(i + 1) = (d(i) - val_lambda) * P(i) - s(i - 1).^2 * P(i - 1); %se afla pe rand valorea fiecarui polinom P(k), de la k=3 la k=n.
    endfor %aflarea valorii P(n) in punctul val_lambda a sirului P(k), unde n este ordinul matricei. P(n) in punctul val_lambda reprezinta valoarea polinomului caracteristic al matricei tridiagonale calculat in punctul val_lambda.
  
  endfunction