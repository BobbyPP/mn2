function A_mult_vecp = multiply_matr_vecp (d, s, vecp)
  
  len_d = length(d);
  
  A_mult_vecp(1) = d(1) * vecp(1) + s(1) * vecp(2);
  for i = 2 : len_d - 1
    A_mult_vecp(i) = s(i - 1) * vecp(i - 1) + d(i) * vecp(i) + s(i) * vecp(i + 1);
    endfor
  A_mult_vecp(len_d) = s(len_d - 1) * vecp(len_d - 1) + d(len_d) * vecp(len_d);
  
  endfunction