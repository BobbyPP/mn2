function [multp1p2] = multiplpol (p1, p2)
  
  len1 = length(p1);
  len2 = length(p2);
  
  if len1 < len2
    for i = 1 : len2 - len1
      p10(i) = 0;
      endfor
    for i = 1 : len1
      p10(len2 - len1 + i) = p1(i);
      endfor
    for i = 1 : len2
      p1(i) = p10(i);
      endfor
    endif
  
  if len1 > len2
    for i = 1 : len1 - len2
      p20(i) = 0;
      endfor
    for i = 1 : len2
      p20(len1 - len2 + i) = p2(i);
      endfor
    for i = 1 : len1
      p2(i) = p20(i);
      endfor
    endif
  
  for i = 1 : length(p1) + length(p2)
    p1p2(i) = 0;
    endfor
  
  for i = 1 : length(p1)
    for j = 1 : length(p2)
      p1p2(i + j) = p1p2(i + j) + p1(i) * p2(j);
      endfor
    endfor
  
  poz = 0;
  for i = 1 : length(p1p2)
    if(p1p2(i) != 0)
      poz = poz + 1;
      multp1p2(poz) = p1p2(i);
      endif
    endfor
  
  for i = poz + 1 : len1 + len2 - 1
    multp1p2(i) = 0;
    endfor
  
  endfunction