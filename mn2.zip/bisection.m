function [x] = bisection (f, a, b)
  
  xold = a;
  xnew = b;
  tol = 0.00001;
  
  while ( norm (xnew - xold) > tol )
    if calcfun (f, (xold+xnew)/2 ) == 0
      return;
      endif
    if norm(xnew - xold) < tol
      return;
      endif
    if calcfun (f, xold) * calcfun (f, xnew) < 0
      if calcfun (f, xold) * calcfun (f, (xnew + xold)/2) < 0
        xnew = (xnew + xold)/2;
        endif
      if calcfun (f, (xnew + xold)/2) * calcfun (f, xnew) < 0
        xold = (xnew + xold)/2;
        endif
      endif
    endwhile
  
  x = xold;
  
  endfunction