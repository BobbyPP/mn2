function r = IntervaleValProprii(d, s, m)
  
  %In cazul in care se introduce ca input un numar de valori proprii mai mare decat ordinul matricei, se reduce automat acel numar la ordinul matricei (care este numarul maxim de valori proprii ale matricei).
  if m > length(d)
    m = length(d);
    endif
  
  %In cazul in care se introduce m (numarul de valori proprii) mai mic decat 1, atunci acesta se initializeaza automat cu 1.
  if m < 1
    m = 1
    endif
  
  %r(1) se initializeaza cu limita inferioara a valorilor proprii, iar aux cu limita superioara a valorilor proprii. Acestea vor ramane constante, ca si capete de intervale.
  [r(1) aux] = LimiteValProprii(d, s);
  
  %Se formeaza efectiv intervalele.
  for k = m : -1 : 1
    if m == k
      mij = (aux + r(1)) / 2; %Se alege mijlocul intervalului [r(1) r(k+2)]
      h = aux - mij;  %h este inaltimea jumatatii superioare a intervalului [r(1) aux]
    else
      mij = (r(k + 2) + r(1)) / 2; %Se alege mijlocul intervalului [r(1) r(k+2)]
      h = r(k + 2) - mij;
      endif
    numvp = NrValProprii(d, s, mij); %Se calculeaza numarul de valori proprii mai mici decat mijlocul m.
    while numvp != k %Se cauta ca pentru iteratia k (de la m la 1) sa se gaseasca un interval asa incat sa cuprinda fix k valori proprii.
      numvp = NrValProprii(d, s, mij);
      h = h / 2;
      if numvp < k %Conditia pentru care in intervalul ales (adica [r(1) mij]) se gasesc mai putin de k valori proprii.
        mij = mij + h; %Se extinde intervalul cu h la capatul superior.
      else
        if numvp > k %Conditia pentru care in intervalul ales (adica [r(1) mij]) se gasesc mai mult de k valori proprii.
          mij = mij - h; %Se restrange intervalul cu h de la capatul superior.
        endif
      endif
    endwhile
    r(k + 1) = mij; %Se atribuie valoarea corecta elementului k + 1 din sirul ce delimiteaza intervalele in care se gasesc valorile proprii.
    endfor
  
endfunction