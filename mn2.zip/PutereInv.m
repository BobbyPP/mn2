function [valp vecp] = PutereInv(d, s, h, y, maxIter, tol)
  
  len_d = length(d); %Se atribuie variabilei len_d numarul ordinului matricei.
  
  for i = 1 : len_d
    vecp(i) = y(i); %Se realizeaza aproximatia initiala a vectorului propriu corespunzator valorii proprii valp.
    endfor
  
  A_mult_vecp = multiply_matr_vecp(d, s, vecp); %Functiile multiply_matr_vecp, respectiv multiply_vecp_matr, fac inmultirea dintre matricea tridiagonala si vectorul vecp, respectiv intre vectorul vecp si matricea tridiagonala.
  valp = 10; %Se aproximeaza initial si valoarea proprie (valp).
  
  nr_iter = 0; %nr_iter = numarul curent de iteratii efectuate.
  while (norm(multiply_matr_vecp(d, s, vecp * (1 / vecp(1))) - valp * (vecp * (1 / vecp(1)))) >= tol || nr_iter < 1) && nr_iter < maxIter
    for i = 1 : len_d
      d_prim(i) = d(i) - h;
      endfor
    %Se aplica efectiv algoritmul puterii inverse.
    z = Thomas(s, d_prim, vecp); %Se aplica algoritmul Thomas pentru aflarea solutiei ecuatiei (A - h * I) * z = vecp.
    vecp = z * (1 / norm(z));
    valp = vecp * (multiply_matr_vecp(d, s, vecp))';
    h = valp;
    nr_iter = nr_iter + 1; %Cresterea numarului de iteratii.
    endwhile
  
  endfunction